package MVC;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Annotation.RequestMapping;
import dev.edu.javaee.spring.factory.BeanFactory;
import dev.edu.javaee.spring.factory.XMLBeanFactory;
import dev.edu.javaee.spring.resource.LocalFileResource;
import test.test;
public class DispathcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DispathcherServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stubresponse.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");  
		Enumeration enu=request.getParameterNames();  
		
		ModelAndView mdv=new ModelAndView();
		
		while(enu.hasMoreElements()){   //ֵ
		String paraName=(String)enu.nextElement();  
		  mdv.putMap(paraName, request.getParameter(paraName));
		}
		
	    String uri = request.getServletPath() ;  //hello 
	    System.out.println(uri);
	    
	     //controller
	    // List<String> fileNames = Package.getClassName("test");
	    
        LocalFileResource resource = new LocalFileResource("/D:/eclipse-jee-mars-2-win32-x86_64/CreateMVC/src/MVC/bean.xml");
		
		BeanFactory beanFactory = new XMLBeanFactory(resource);
       
		test test= (test) beanFactory.getBean("test");   //control
		
		Method[]  methods = test.getClass().getMethods();
		
		
		try{
		    for (Method m : methods){
			    RequestMapping requestmapano = m.getAnnotation(RequestMapping.class);
			    String value = requestmapano.value();
			
			    if(value.equals(uri)){  
				
				    ModelAndView return_mdv=(ModelAndView)m.invoke(test,mdv);
				    uri=return_mdv.getViewName(); 
				    List<String> keys = new ArrayList<String>(return_mdv.responseMap.keySet());
				    Collections.sort(keys);
				    for(String key : keys){
				          request.setAttribute(key,return_mdv.responseMap.get(key));
				    }
				    break;
			    }
		    }
		}catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e){
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
//		 List<String> fileNames = Package.getClassName("test");
//		    for (String fileName : fileNames){
//		    	try {
//					Class<?> cls = Class.forName(fileName);
//					Method[] methods = cls.getMethods();
//					for (Method m : methods){
//						RequestMapping rm = m.getAnnotation(RequestMapping.class);
//						String value = rm.value();
//						if(value.equals(uri)){
//							ModelAndView mm=(ModelAndView)m.invoke(cls.newInstance(),mdv);
//							uri=mm.getViewName();
//							List<String> keys = new ArrayList<String>(mm.map1.keySet());
//							Collections.sort(keys);
//							for(String key : keys){
//							  request.setAttribute(key ,mm.map1.get(key));
//							}
//							break;
//						}
//					}
//				} catch (ClassNotFoundException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (IllegalArgumentException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (NullPointerException e){
//					
//				} catch (IllegalAccessException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (InvocationTargetException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (InstantiationException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//		    }
		
			
	    request.getRequestDispatcher(uri+".jsp").forward(request,response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
    }
}
